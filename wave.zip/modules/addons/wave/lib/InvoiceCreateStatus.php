<?php

namespace Subbe\WaveApp;

class InvoiceCreateStatus
{
    const DRAFT = 'DRAFT';
    const SAVED = 'SAVED';
}
