<?php

namespace WHMCS\Module\Addon\Wave;

class InvoiceCreateStatus
{
    const DRAFT = 'DRAFT';
    const SAVED = 'SAVED';
}
