<?php

namespace WHMCS\Module\Addon\Wave;

class AccountTypeValue
{
    const ASSET = 'ASSET';
    const EQUITY = 'EQUITY';
    const EXPENSE = 'EXPENSE';
    const INCOME = 'INCOME';
    const LIABILITY = 'LIABILITY';
}
