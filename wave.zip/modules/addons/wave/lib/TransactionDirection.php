<?php

namespace WHMCS\Module\Addon\Wave;

class TransactionDirection
{
    const DEPOSIT = 'DEPOSIT';
    const WITHDRAWAL = 'WITHDRAWAL';
}
