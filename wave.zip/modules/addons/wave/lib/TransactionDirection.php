<?php

namespace Subbe\WaveApp;

class TransactionDirection
{
    const DEPOSIT = 'DEPOSIT';
    const WITHDRAWAL = 'WITHDRAWAL';
}
