<?php

namespace WHMCS\Module\Addon\Wave;

class TransactionOrigin
{
    const MANUAL = 'MANUAL';
    const ZAPIER = 'ZAPIER';
}
