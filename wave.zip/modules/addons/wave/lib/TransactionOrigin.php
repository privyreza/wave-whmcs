<?php

namespace Subbe\WaveApp;

class TransactionOrigin
{
    const MANUAL = 'MANUAL';
    const ZAPIER = 'ZAPIER';
}
