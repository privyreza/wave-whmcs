<?php

namespace Subbe\WaveApp;

class CustomerSort
{
    const CREATED_AT_ASC = 'CREATED_AT_ASC';
    const CREATED_AT_DESC = 'CREATED_AT_DESC';
    const MODIFIED_AT_ASC = 'MODIFIED_AT_ASC';
    const MODIFIED_AT_DESC = 'MODIFIED_AT_DESC';
    const NAME_ASC = 'NAME_ASC';
    const NAME_DESC = 'NAME_DESC';
}
