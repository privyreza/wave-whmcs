<?php

namespace WHMCS\Module\Addon\Wave;

class OrganizationalType
{
    const CORPORATION = 'CORPORATION';
    const PARTNERSHIP = 'PARTNERSHIP';
    const SOLE_PROPRIETORSHIP = 'SOLE_PROPRIETORSHIP';
}
