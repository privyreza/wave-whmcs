<?php

namespace Subbe\WaveApp;

class OrganizationalType
{
    const CORPORATION = 'CORPORATION';
    const PARTNERSHIP = 'PARTNERSHIP';
    const SOLE_PROPRIETORSHIP = 'SOLE_PROPRIETORSHIP';
}
