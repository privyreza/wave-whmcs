<?php

namespace WHMCS\Module\Addon\Wave;

class AccountNormalBalanceType
{
    const CREDIT = 'CREDIT';
    const DEBIT = 'DEBIT';
}
