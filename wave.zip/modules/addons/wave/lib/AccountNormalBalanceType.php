<?php

namespace Subbe\WaveApp;

class AccountNormalBalanceType
{
    const CREDIT = 'CREDIT';
    const DEBIT = 'DEBIT';
}
